package com.example.service;

import com.example.domain.MissionUserVO;
import com.example.domain.MissionVO;

public interface MissionService {
	public void insert(MissionUserVO vo);
}
