//package com.example.service;
//
//
//import com.example.domain.UserPointVO;
//
//public interface UserPointService {
//	public void gradeUpdate(UserPointVO vo);
//	public void pointUpdate(UserPointVO vo, int getPoint);
//
//
//}
