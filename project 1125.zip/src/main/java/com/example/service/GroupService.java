package com.example.service;

import com.example.domain.GroupVO;

public interface GroupService {

	public void groupinsert(GroupVO vo);
}
