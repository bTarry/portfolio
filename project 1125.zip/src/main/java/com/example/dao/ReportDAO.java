package com.example.dao;

import java.util.List;

import com.example.domain.ReportVO;

public interface ReportDAO {
	public List<ReportVO> reportList();
}
