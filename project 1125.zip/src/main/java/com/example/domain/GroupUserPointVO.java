package com.example.domain;

public class GroupUserPointVO {

	private int group_user_point_code;
	private int group_user_point;
	private String group_point_code;
	private String group_user_point_id;
	public int getGroup_user_point_code() {
		return group_user_point_code;
	}
	public void setGroup_user_point_code(int group_user_point_code) {
		this.group_user_point_code = group_user_point_code;
	}
	public int getGroup_user_point() {
		return group_user_point;
	}
	public void setGroup_user_point(int group_user_point) {
		this.group_user_point = group_user_point;
	}
	public String getGroup_point_code() {
		return group_point_code;
	}
	public void setGroup_point_code(String group_point_code) {
		this.group_point_code = group_point_code;
	}
	public String getGroup_user_point_id() {
		return group_user_point_id;
	}
	public void setGroup_user_point_id(String group_user_point_id) {
		this.group_user_point_id = group_user_point_id;
	}
	
	
	
	
	
}
